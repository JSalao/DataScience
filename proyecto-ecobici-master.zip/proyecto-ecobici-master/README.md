# Proyecto EcoBici

Repositorio para el artículo de Medium https://medium.com/p/f861a25b9677

Los datos están en https://github.com/gonzalezgouveia/proyecto-ecobici/tree/master/datos

El jupyter notebook está en https://github.com/gonzalezgouveia/proyecto-ecobici/tree/master/jupyter_notebook

Comentarios, incidencias, etc https://github.com/gonzalezgouveia/proyecto-ecobici/issues
